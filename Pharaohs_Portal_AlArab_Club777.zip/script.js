const chatSphere = document.getElementById('chatSphere');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');

function typeWriter(element, text, speed = 35) {
  let i = 0;
  function typing() {
    if (i < text.length) {
      element.textContent += text.charAt(i);
      i++;
      setTimeout(typing, speed);
    }
  }
  typing();
}

function addMessage(text, isUser = true) {
  const msg = document.createElement('div');
  msg.classList.add('message');
  msg.classList.add(isUser ? 'user' : 'ai');
  chatSphere.appendChild(msg);
  chatSphere.scrollTop = chatSphere.scrollHeight;
  if (isUser) {
    msg.textContent = text;
  } else {
    typeWriter(msg, text);
  }
}

async function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;
  addMessage(message, true);
  userInput.value = '';
  // رد افتراضي (يمكن ربطه لاحقاً بـ OpenAI)
  setTimeout(() => addMessage("𓂀 AlArab Club 777 — Coming soon...", false), 400);
}

sendBtn.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendMessage());
