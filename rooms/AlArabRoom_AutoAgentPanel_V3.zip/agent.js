document.addEventListener("DOMContentLoaded", () => {
  const agents = [
    { name: "Agent Horus", task: "Initialize protocol 777" },
    { name: "Agent Anubis", task: "Secure visitor data" },
    { name: "Agent Isis", task: "Scan and analyze environment" }
  ];
  const panel = document.getElementById("agentsPanel");
  agents.forEach(agent => {
    const box = document.createElement("div");
    box.className = "agent-box";
    box.innerHTML = `<h3>${agent.name}</h3><p>${agent.task}</p><button class="agent-button" onclick="alert('${agent.name} executing: ${agent.task}')">Execute</button>`;
    panel.appendChild(box);
  });
});
