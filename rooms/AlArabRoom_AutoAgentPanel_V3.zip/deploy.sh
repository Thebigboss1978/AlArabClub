#!/bin/bash
# Auto deploy script for AlArab Room
vercel --prod --yes
